export default class AbstractAgent {
  constructor(win) {
    this._win = win;
  }
}
